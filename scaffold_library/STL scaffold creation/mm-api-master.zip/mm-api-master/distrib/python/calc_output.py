import os
import pyvista as pv
import csv

# Specify the folder path
folder_path = 'remotely_generated_scaffold'  # Replace with the actual folder path

# List all files in the folder

results=[]

file_list = os.listdir(folder_path)

# Iterate through each file in the folder
for file_name in file_list:
    # Check if the file is an STL file
    if file_name.lower().endswith('.stl'):
        # Create the full file path
        file_path = os.path.join(folder_path, file_name)
        
        print(file_path)
        # Load the STL file
        mesh = pv.read(file_path)

        # Calculate the volume of the scaffold
        solid_volume = mesh.volume

        # Triangulate the mesh
        triangulated_mesh = mesh.triangulate()

        # Calculate the surface area
        surface_area = triangulated_mesh.compute_cell_sizes()['Area'].sum()

        # Calculate the surface-to-volume ratio
        surface_to_volume_ratio = surface_area / solid_volume

        # Get the bounds of the mesh
        bounds = mesh.bounds

        # Calculate the volume of the bounding box
        bounding_box_volume = (bounds[1] - bounds[0]) * (bounds[3] - bounds[2]) * (bounds[5] - bounds[4])

        # Calculate the percentage of empty space
        empty_space_percentage = 100.0 * (1.0 - solid_volume / bounding_box_volume)

        # Append results to the list
        results.append({
            'File': file_name,
            'Empty_Space_Percentage': empty_space_percentage,
            'Surface_to_Volume_Ratio': surface_to_volume_ratio
        })

# Print the results for each file
for result in results:
    # Print the results
    print("File: ", result['File'])
    print("Percentage of Empty Space: ", result['Empty_Space_Percentage'])
    print("Surface-to-Volume Ratio: ", result['Surface_to_Volume_Ratio'])


# Specify the CSV file path
csv_file_path = 'results.csv'  # Replace with the desired file path

# Save the results to a CSV file
with open(csv_file_path, mode='w', newline='') as csv_file:
    fieldnames = ['File', 'Empty_Space_Percentage', 'Surface_to_Volume_Ratio']
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    
    # Write the header
    writer.writeheader()
    
    # Write the results
    for result in results:
        writer.writerow(result)

        