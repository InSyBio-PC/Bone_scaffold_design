import pyvista as pv
import numpy as np
from scipy import ndimage

# Load the STL file
stl_filename = "104x104x34_0.4x0.4x0.15x0.15.stl"
mesh = pv.read(stl_filename)

# Check the available arrays in the mesh
print(mesh.array_names)

# Replace 'your_scalar_array_name' with the name of the scalar array you want to use for thresholding
scalar_array_name = 'your_scalar_array_name'

# Check if the scalar array exists in the mesh
if scalar_array_name in mesh.array_names:
    # Convert the mesh to a binary image using the specified scalar array
    binary_image = mesh.threshold(0.5, scalars=scalar_array_name)  # Adjust the threshold as needed

    # Perform skeletonization (thinning) on the binary image
    skeleton = ndimage.morphology.skeletonize(binary_image.point_data[scalar_array_name])

    # Calculate trabecular thickness using distance transform
    distance_transform = ndimage.distance_transform_edt(binary_image.point_data[scalar_array_name])
    trabecular_thickness = 2 * np.max(distance_transform)

    # Calculate trabecular spacing (average spacing between trabeculae)
    trabecular_spacing = np.mean(distance_transform[skeleton])

    print(f"Trabecular Thickness: {trabecular_thickness}")
    print(f"Trabecular Spacing: {trabecular_spacing}")
else:
    print(f"Scalar array '{scalar_array_name}' not found in the mesh.")
