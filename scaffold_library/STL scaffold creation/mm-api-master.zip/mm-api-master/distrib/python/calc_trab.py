import os
import vtk
import numpy as np
from scipy import ndimage

# Load the 3D STL file
stl_filename = "104x104x34_0.4x0.4x0.15x0.15.stl"
reader = vtk.vtkSTLReader()
reader.SetFileName(stl_filename)
reader.Update()
polydata = reader.GetOutput()

# Set the number of slices and the direction of slicing
num_slices = 10  # Adjust the number of slices as needed
slice_direction = [0, 0, 1]  # Slicing in the Z direction, adjust as needed

# Calculate the slicing positions
z_min, z_max = polydata.GetBounds()[4:6]
slice_positions = np.linspace(z_min, z_max, num_slices)

# Initialize lists to store trabecular thickness and spacing for each slice
trabecular_thickness_list = []
trabecular_spacing_list = []

# Define a 2D structuring element
structuring_element = np.array([[1, 1, 1],
                                [1, 1, 1],
                                [1, 1, 1]])

# Iterate through the slices
for z in slice_positions:
    # Extract the slice as a 2D binary image
    plane = vtk.vtkPlane()
    plane.SetOrigin(0, 0, z)
    plane.SetNormal(slice_direction)

    cutter = vtk.vtkCutter()
    cutter.SetInputData(polydata)
    cutter.SetCutFunction(plane)
    cutter.Update()
    slice_polydata = cutter.GetOutput()

    # Convert the slice to a binary image
    slice_binary_image = slice_polydata.GetPointData().GetArray("vtkValidPointMask")

    # Perform skeletonization (thinning) on the binary image (2D)
    skeleton = ndimage.binary_erosion(slice_binary_image, structure=structuring_element)

    # Calculate trabecular thickness using distance transform
    distance_transform = ndimage.distance_transform_edt(slice_binary_image)
    trabecular_thickness = 2 * np.max(distance_transform)

    # Calculate trabecular spacing (average spacing between trabeculae)
    trabecular_spacing = np.mean(distance_transform[skeleton])

    trabecular_thickness_list.append(trabecular_thickness)
    trabecular_spacing_list.append(trabecular_spacing)

# Now you have lists of trabecular thickness and spacing for each slice
# You can analyze and visualize these data as needed

for i, (thickness, spacing) in enumerate(zip(trabecular_thickness_list, trabecular_spacing_list)):
    print(f"Slice {i + 1} - Trabecular Thickness: {thickness}, Trabecular Spacing: {spacing}")
