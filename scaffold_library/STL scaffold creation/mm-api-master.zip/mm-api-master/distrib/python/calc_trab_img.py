from PIL import Image
import cv2
import numpy as np
from skimage.morphology import skeletonize
import tifffile

# Load the .tif image using PIL (Pillow)
#image_path = "Foam_Denser_002148.tif"
image_path = "Foam_Broader_000787.tif"

# with tifffile.TiffFile(image_path) as tif:
    # metadata = tif.pages[0].description

#Print the metadata
# print("Image Metadata:")
# print(metadata)

#image = Image.open(image_path)

image = cv2.imread(image_path)

# Convert the image to grayscale for processing
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Use contour detection to find the region of interest
contours, _ = cv2.findContours(gray, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
if contours:
    # Find the largest contour (assumes the interesting region is the largest)
    largest_contour = max(contours, key=cv2.contourArea)

    # Get the bounding box of the largest contour
    x, y, w, h = cv2.boundingRect(largest_contour)

    # Crop the image to the region of interest
    cropped_image = image[y:y + h, x:x + w]

    # Display the original and cropped images
    cv2.imshow("Original Image", image)
    cv2.imshow("Cropped Image", cropped_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    
    
    # Convert the image to a NumPy array
    image_array = np.array(cropped_image)

    # Perform skeletonization (thinning) on the binary image using scikit-image
    skeleton = skeletonize(image_array)

    # Calculate trabecular thickness using distance transform
    distance_transform = skeleton * 0  # Initialize with zeros
    distance_transform[skeleton] = np.arange(1, np.sum(skeleton) + 1)
    trabecular_thickness = 2 * np.max(distance_transform)  # Assuming binary image

    # Calculate trabecular spacing (average spacing between trabeculae)
    trabecular_spacing = np.mean(distance_transform[skeleton])

    print(f"Trabecular Thickness: {trabecular_thickness}")
    print(f"Trabecular Spacing: {trabecular_spacing}")
else:
    print("No contour found. Unable to crop the image.")


