from Tkinter import *
import Tkinter as tk
import tkFileDialog
from tkFileDialog import askopenfilename

import mmapi
from mmRemote import *
import pandas as pd
import threading
import Queue
import os
import time
from win32com.client import Dispatch
import subprocess
import psutil 
import mm

# Clear the console
os.system('cls')

def choose_file(title):
    root = tk.Tk()
    root.attributes("-topmost", True)
    root.withdraw()
    title=title 
    # Show the file dialog to select a CSV file
    selected_file = tkFileDialog.askopenfilename(
        title=title,
        filetypes=[("All files", "*.*"), ("Text files", "*.txt")]
    )

    # Return the path of the selected file
    return selected_file

file_path = choose_file("Choose the CSV file with the scaffold parameters")

global remote, patt1, rip 
def check_meshmixer_running():
    # Iterate over all running processes and check for Meshmixer
    for process in psutil.process_iter(attrs=['name']):
        try:
            if "meshmixer.exe" in process.info['name']:  # Look for Meshmixer in the process list
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return False

def connect_to_meshmixer():
    if not check_meshmixer_running():
        print("Error: Meshmixer is not running, open Meshmixer and try again.")
        sys.exit(1)  

# Connect to Meshmixer
remote = mmRemote()
remote.connect()
connect_to_meshmixer()

def read_csv_file(file_path, rows=None, columns=[0, 1, 2, 3]):
    
    # Read the CSV file with the specified columns and rows
    df = pd.read_csv(file_path, sep=';', header=None, usecols=columns, nrows=rows, 
                     names=["Sphere Distance", "Sphere Diameter", "Delaunay Mesh Dimension", "Delaunay Point Spacing"])
    
    # Filter rows to keep only those where all columns have numeric data
    df = df.apply(pd.to_numeric, errors='coerce')  
    df = df.dropna()  

    # Print the dataframe to see the content
    print(df)
    
    # Convert the dataframe to a NumPy array and exclude the first column (index 0)
    matrix = df.to_numpy()
    matrix = matrix[:, 1:]  # Remove the first column if not needed
    
    return matrix

matrix=read_csv_file(file_path, rows=None)
rip = 1
patt1 = 7
patt2 = 2


def Load_File():
    global remote, patt1, rip, dim1, dim2, spac1, spac2
    root.destroy()
    path_file= choose_file("Choose the STL file that is the parallelepiped base of your scaffold")
    final_path = path_file.replace("/", "//")
    normal_path = str(final_path)
    
    #Choose save path
    root1 = tk.Tk()
    root1.attributes("-topmost", True)
    root1.withdraw()
    
    save_path = tkFileDialog.askdirectory(title="Choose the folder where to save the files")
    final_save_path = save_path.replace("/", "//")
    normal_save_path = str(final_save_path)


                   
    for i, row in enumerate(matrix, start=1):        
        dim1 = [row[0]] * 3
        dim2 = [row[1]] * 3
        spac2 = [row[2]] * 3
        print("Creating scaffold number %d" % (i))
        spac1 = dim1
        output = "{}x{}x{}x{}".format(dim1[1], spac1[1], dim2[1], spac2[1])
    
        default_filename = "{}.stl".format(output)
        current_save_path = os.path.join(normal_save_path, default_filename)
    
        cmd = mmapi.StoredCommands()
            
        if normal_path == "":
              return
        else:
            cmd.AppendSceneCommand_AppendMeshFile(str(normal_path))
            remote.runCommand(cmd)
            if run_with_timeout(Patterns, (normal_path, 1), 3600):
               print("Scaffold number %d created" % (i))
               Save_File(current_save_path, remote, mm)
                    
            else:
                print("Timeout occurred, moving to next row.")
                    
    
                restart_meshmixer()  
                cmd.AppendSceneCommand_Clear();
                time.sleep(10)
    
    print("All rows have been processed. Exiting...")
    exit(0)


    
# Function to run Patterns with timeout
def run_with_timeout(func, args, timeout):
    q = Queue.Queue()

    def wrapper():
        result = func(*args)
        q.put(result)

    t = threading.Thread(target=wrapper)
    t.start()
    t.join(timeout)
    if t.is_alive():
        print("Function timed out")
        return False
    else:
        return True
    

def Patterns(path_to_file, ii):
    cmd = mmapi.StoredCommands()

    cmd.AppendBeginToolCommand("makePattern")
    cmd.AppendToolParameterCommand("pattern", patt1)
    cmd.AppendToolParameterCommand("dimension1", dim1[ii])
    cmd.AppendToolParameterCommand("spacing1", spac1[ii])
    cmd.AppendToolParameterCommand("clipToSurface", True)
    cmd.AppendToolParameterCommand("compositionMode", 0)
    cmd.AppendCompleteToolCommand("accept")

    cmd.AppendBeginToolCommand("makePattern")
    cmd.AppendToolParameterCommand("pattern", patt2)
    cmd.AppendToolParameterCommand("dimension1", dim2[ii])
    cmd.AppendToolParameterCommand("spacing1", spac2[ii])
    cmd.AppendToolParameterCommand("clipToSurface", True)
    cmd.AppendToolParameterCommand("compositionMode", 0)
    cmd.AppendCompleteToolCommand("accept")

    cmd.AppendBeginToolCommand("makeSolid")
    cmd.AppendToolParameterCommand("solidType", 1)
    cmd.AppendCompleteToolCommand("accept")

    cmd.AppendBeginToolCommand("Inspector")
    cmd.AppendToolParameterCommand("smallComponentThreshold", 0.1)
    cmd.AppendToolParameterCommand("replaceType", 0)
    cmd.AppendCompleteToolCommand("accept")

    remote.runCommand(cmd)



def Save_File(save_path, remote, mm):
    print("Saving file...")
    
    # If the user selects a path, save the file
    if save_path:
        mm.export_mesh(remote, save_path) 
        cmd = mmapi.StoredCommands()
        cmd.AppendSceneCommand_Clear()
        remote.runCommand(cmd)
        print("File saved successfully at: {}".format(save_path))
    else:
        print("Save operation cancelled.")


# Path to Meshmixer shortcut
shortcut_path = r"C:\\Users\\mengo\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Autodesk\\Meshmixer.lnk"

# Function to resolve shortcut to executable
def resolve_shortcut(shortcut_path):
    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(shortcut_path)
    return shortcut.Targetpath

# Function to restart Meshmixer
def restart_meshmixer():
    # Resolve the shortcut to get the executable path
    meshmixer_path = resolve_shortcut(shortcut_path)

    # Close Meshmixer
    os.system("taskkill /f /im meshmixer.exe")
    
    # Wait for a few seconds to ensure it has closed
    time.sleep(3)
    
    # Reopen Meshmixer
    subprocess.Popen([meshmixer_path])


# Setup a tiny GUI window:    
root = Tk()
root.title("Make Scaffolds")
w = 480
h = 100

ws = root.winfo_screenwidth()  # Width of the screen
hs = root.winfo_screenheight()  # Height of the screen

x = (ws // 2) - (w // 2)  
y = (hs // 2) - (h // 2)  
root.geometry('%dx%d+%d+%d' % (w, h, x, y))

root.attributes("-topmost", True)

buttonLoad = Button(root, text="Start", command=Load_File)
buttonLoad.pack()

def on_closing():
    remote.shutdown()
    root.destroy()    

root.protocol("WM_DELETE_WINDOW", on_closing)
root.mainloop()
